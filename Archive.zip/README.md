# project-fa19
CS 170 Fall 2019 Project
HOW TO RUN
1.Download Zip file and unzip
2.Once unzipped, open command terminal and navigate to directory containing source code
3.Once in correct directory, run command:
  python3 solver.py --all inputs outputs
    -inputs is folder of inputs
    -outputs is folder where outputs to each corresponding input will be written to
