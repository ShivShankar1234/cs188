import random
alphabet = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "O", "P", "Q", "R", "S", "T", "U", "W", "X", "Y", "Z"]
numLocations = 200
numHomes = 100
startingVertex = 0
locationNames = []
homeNames = []
adjacencyMatrix = []

def forceSolution(adjMatrix, homes):
    start = 0
    for home in homes:
        if adjMatrix[start][int(home)] == "x":
            adjMatrix[start][int(home)] = "1"
            adjMatrix[int(home)][start] = "1"
        start = int(home)

def compareAdjMatrix(matrix1, matrix2):
    for i in range(len(matrix1)):
        for j in range(len(matrix1[i])):
            if matrix1[i][j] != matrix2[i][j]:
                print("DIFFERENCE AT: " +str(i) + " " + str(j))


for i in range(numLocations):
    locationNames.append(str(i))

for i in range(numHomes):
    homeName = str(random.randint(1, numLocations-1))
    while homeName in homeNames:
        homeName = str(random.randint(1, numLocations-1))
    homeNames.append(homeName)

for i in range(numLocations):
    row = []
    for j in range(numLocations):
        row.append("x")
    adjacencyMatrix.append(row)

for i in range(numLocations):
    for j in range(i+1, numLocations):
        edgePres = random.randint(0, 1)
        if edgePres != 0:
            adjacencyMatrix[i][j] = edgePres
            adjacencyMatrix[j][i] = edgePres

print(numLocations)
print(numHomes)
for i in locationNames:
    print(i, end=" ")
print()
for i in homeNames:
    print(i, end=" ")
print()
print(startingVertex)

deepcopy = []
for i in adjacencyMatrix:
    row = []
    for j in i:
        row.append(j)
#        print(j, end=" ")
    deepcopy.append(row)
#    print()

print("HERE IS THE BREAK BETWEEN original MATRIX AND A MATrix WITH A FORCED SOLUTION")

forceSolution(adjacencyMatrix, homeNames)

print()

#for i in adjacencyMatrix:
#    for j in i:
#        print(j, end=" ")
#    print()

compareAdjMatrix(deepcopy, adjacencyMatrix)


