def forceSolution(adjMatrix, homes):
    start = 0
    for home in homes:
        if adjMatrix[start][home] == "x":
            adjMatrix[start][home] = "1"
            adjMatrix[home][start] = "1"
        start = home




